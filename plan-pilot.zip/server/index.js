const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

function generatePlan(topics, hoursAvailable) {
  const perTopicTime = hoursAvailable / topics.length;
  const schedule = topics.map((topic, i) => ({
    timeSlot: `${9 + i}:00 - ${10 + i}:00`,
    topic,
    duration: `${perTopicTime.toFixed(1)} hrs`
  }));
  return schedule;
}

app.post('/api/plan', (req, res) => {
  const { topics, hours } = req.body;
  const plan = generatePlan(topics, hours);
  res.json({ plan });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
