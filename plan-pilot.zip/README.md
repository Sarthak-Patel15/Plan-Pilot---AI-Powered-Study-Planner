# 🧠 Plan Pilot – AI-Powered Study Planner

Plan Pilot is a smart, minimal AI study planner that distributes your available hours across topics. Perfect for learners looking for structure and clarity.

## 🔧 Tech Stack
- React + Vite (Frontend)
- Express + Node.js (Backend)
- Tailwind CSS (Optional Styling)

## 📦 How to Run

1. **Start Backend**
```bash
cd server
npm install
npm start
```

2. **Start Frontend**
```bash
cd client
npm install
npm run dev
```

3. Open `http://localhost:5173`

## 📤 Deployment
This project is modular and ready to be deployed on services like Vercel (frontend) and Render or Railway (backend).

---
Made with ❤️ for productivity.
