import React, { useState } from 'react';
import axios from 'axios';

export default function App() {
  const [topics, setTopics] = useState('DSA, Web Dev, AI');
  const [hours, setHours] = useState(4);
  const [plan, setPlan] = useState([]);

  const generatePlan = async () => {
    const topicList = topics.split(',').map(t => t.trim());
    const res = await axios.post('http://localhost:5000/api/plan', {
      topics: topicList,
      hours: Number(hours)
    });
    setPlan(res.data.plan);
  };

  return (
    <div className="p-8 max-w-xl mx-auto text-center">
      <h1 className="text-2xl font-bold mb-4">📚 Plan Pilot – AI Study Planner</h1>
      <input
        className="border p-2 w-full mb-2"
        value={topics}
        onChange={e => setTopics(e.target.value)}
        placeholder="Enter topics (comma separated)"
      />
      <input
        type="number"
        className="border p-2 w-full mb-2"
        value={hours}
        onChange={e => setHours(e.target.value)}
        placeholder="Total hours available"
      />
      <button
        onClick={generatePlan}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >Generate Plan</button>

      <div className="mt-6 text-left">
        {plan.map((item, idx) => (
          <div key={idx} className="border-b py-2">
            <strong>{item.timeSlot}</strong> – {item.topic} ({item.duration})
          </div>
        ))}
      </div>
    </div>
  );
}
